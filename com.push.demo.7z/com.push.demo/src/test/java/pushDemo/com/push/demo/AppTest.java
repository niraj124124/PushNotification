package pushDemo.com.push.demo;

import java.io.FileInputStream;
import java.io.IOException;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest 
    
{
	public static void main( String[] args ) throws IOException, FirebaseMessagingException
	{

		String registrationToken = "dWl7RFsWh3U:APA91bHJo_iAIi1i4pHZOxWP2diQmyTtjO5mNh--DlaQj_wzZ9_xNtQcS4AXgaUmpmJ4xo5R3BA94Gy-P1qjIJ8sMHmAFBQy50U26DSv04RjyTNBTIxXwzDBuDblZ-Wq6ApwlOHGBHGw";  	
		FileInputStream serviceAccount =
				new FileInputStream("D:\\SEWA_WORKSPACE_2019\\com.push.demo\\pushnotificationdemo-86376-39957b0bfded.json");
		
		FirebaseOptions options = new FirebaseOptions.Builder()
				.setCredentials(GoogleCredentials.fromStream(serviceAccount))
				//.setDatabaseUrl("https://mmsdevfirebase.firebaseio.com")
				.build();

		FirebaseApp.initializeApp(options);


		//See documentation on defining a message payload.
		Message message = Message.builder()
				.putData("message", "Hello World")
				.setToken(registrationToken)
				.build();

		//Send a message to the device corresponding to the provided
		//registration token.
		String response = FirebaseMessaging.getInstance().send(message);
		//Response is a message ID string.
		System.out.println("Successfully sent message: " + response);

		///////////////////////////////////////////////////////////////////////




	}
}
